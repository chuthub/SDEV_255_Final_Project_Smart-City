Teacher-course-Scheduler.html - This page is where the teacher can add or remove current courses that will be displayed to the index.html (Student class listings)

index.html - This page is the students class listing page, where you can add Available courses to your schedule, or drop them from your schedule (which will put them back in the available courses)

login.html - This is the home page, where the website will be directed to at launch, it is also where the not-authorized page leads to where it says you are not authorized to access to page.)

not-authorized.html - this is where you are led to if you try to access a page that you are not allowed to enter, maybe a student tries to go to a teacher page.